import java.io.*;



import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.*;
/**
 * Servlet implementation class o3
 */
public class o3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public o3() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		try
		{
			if(request.getParameter("View")!=null)
			{
				String st="select * from otherusers;";
				Class.forName("com.mysql.cj.jdbc.Driver");
				String url="jdbc:mysql://localhost:3306/pas?characterEncoding=utf8";
				Connection conn=DriverManager.getConnection(url,"root","abcde");
				PreparedStatement pstatement=conn.prepareStatement(st);
				ResultSet rs=pstatement.executeQuery();
				int id,pinno;
				String fname,email,mob,address,city,state,country,ftype,password,fno;
				out.println("<html>");
				out.println("<head><title>DISPLAY FIRM DETAILS</title></head>");
				out.println("<body>");
				out.println("<br><br>");
				out.println("<h1 style='color:purple;background-color:yellow;width:400px;'>DISPLAY FIRM DETAILS</h1>");
				out.println("<br>");
				out.println("<table style='width:100%;'>");
				out.println("<tr style='color:white;background-color:black;'><th>"+"id"+"</th><th>"+"firmname"+"</th><th>"+"emailid"+"</th><th>"+"mobileno"+"</th><th>"+"address"+"</th><th>"+"city"+"</th><th>"+"state"+"</th><th>"+"country"+"</th><th>"+"firmtype"+"</th><th>"+"pinno"+"</th><th>"+"password"+"</th><th>"+"firmno"+"</th></tr>");
				while(rs.next())
				{
					id=rs.getInt("id");
					fname=rs.getString("firmname");
					email=rs.getString("email");
					mob=rs.getString("mobileno");
					address=rs.getString("address");
					city=rs.getString("city");
					state=rs.getString("state");
					country=rs.getString("country");
					ftype=rs.getString("firmtype");
					pinno=rs.getInt("pinno");
					password=rs.getString("password");
					fno=rs.getString("firmno");
					out.println("<tr style='color:purple;background-color:yellow;'><td>&emsp;"+id+"</td><td>&emsp;"+fname+"</td><td>&emsp;"+email+"</td><td>&emsp;"+mob+"</td><td>&emsp;"+address+"</td><td>&emsp;"+city+"</td><td>&emsp;"+state+"</td><td>&emsp;"+country+"</td><td>&emsp;"+ftype+"</td><td>&emsp;"+pinno+"</td><td>&emsp;"+password+"</td><td>&emsp;"+fno+"</td></tr>");
					out.println("<br>");
				}
				out.println("</table>");
			}
			else if(request.getParameter("Search")!=null)
			{
				response.sendRedirect("o3.html");
			}
			else if(request.getParameter("Update")!=null)
			{
				response.sendRedirect("o4.html");
			}
		}
		catch(SQLException e)
		{
			System.out.println(e);
		}
		catch(ClassNotFoundException d)
		{
			System.out.println(d);
		}
		out.println("</body>");
		out.println("</html>");
	}

}
