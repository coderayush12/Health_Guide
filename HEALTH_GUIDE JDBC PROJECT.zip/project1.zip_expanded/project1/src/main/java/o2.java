import java.io.*;



import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.*;
/**
 * Servlet implementation class o2
 */
public class o2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public o2() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		int count=0;
		String password="";
		try
		{
			out.println("<html>");
			out.println("<head><title>DETAILS</title></head>");
			out.println("<body>");
			out.println("<form action='o3' method='post'>");
			String st="select * from otherusers where email=?;";
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/pas?characterEncoding=utf8";
			Connection conn=DriverManager.getConnection(url,"root","abcde");
			PreparedStatement pstatement=conn.prepareStatement(st);
			String email=request.getParameter("email");
			String pwd=request.getParameter("password");
			pstatement.setString(1, email);
			ResultSet rs=pstatement.executeQuery();
			while(rs.next()) {
				password=rs.getString("password");
				count++;
			}
			if(count==0)
			{
				out.println("Login Id And Password Are Incorrect");
			}
			else if(pwd.equals(password))
			{
				out.println("<br><br>");
				out.println("<label><center style='color:purple;background-color:yellow;'><b>WELCOME</center></label>");
				out.println("<label><center style='color:purple;background-color:yellow;'><b>"+email+"</center></label>");
				out.println("<br><br>");
				out.println("&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;");
				out.println("<input type='submit' name='View' value='View' style='color:white;background-color:purple;width:5%;height:30px;'>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;");
				out.println("<input type='submit' name='Update' value='Update' style='color:white;background-color:purple;width:5%;height:30px;'>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;");
				out.println("<input type='submit' name='Search' value='Search' style='color:white;background-color:purple;width:5%;height:30px;'>");
			}
			else
			{
				out.println("Password Is Incorrect");
			}
		}
		catch(SQLException e)
		{
			System.out.println(e);
		}
		catch(ClassNotFoundException d)
		{
			System.out.println(d);
		}
		out.println("</form>");
		out.println("</body>");
		out.println("</html>");
	}

}
