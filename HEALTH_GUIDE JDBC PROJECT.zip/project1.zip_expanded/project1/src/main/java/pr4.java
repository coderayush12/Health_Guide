import java.io.*;



import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.*;
/**
 * Servlet implementation class pr4
 */
public class pr4 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public pr4() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		HttpSession session=request.getSession(true);
		try
		{
			String st="update patient set patientid=?,patientname=?,patientage=?,bloodgroup=?,mobileno=?,state=?,city=?,country=?,pinno=?,password=?,aadhaarno=? where emailid=?;";
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/pas?characterEncoding=utf8";
			Connection conn=DriverManager.getConnection(url,"root","abcde");
			PreparedStatement pstatement=conn.prepareStatement(st);
			int patientid=Integer.parseInt(request.getParameter("prid"));
			String patientname=request.getParameter("pnam");
			int patientage=Integer.parseInt(request.getParameter("pag"));
			String bloodgroup=request.getParameter("bgr");
			String mobileno=request.getParameter("mob");
			String state=request.getParameter("stat");
			String city=request.getParameter("cit");
			String country=request.getParameter("countr");
			int  pinno=Integer.parseInt(request.getParameter("pin"));
			String password=request.getParameter("passwo");
			String aadhaarno=request.getParameter("aadhaa");
			String email=String.valueOf(session.getAttribute("email1"));
			pstatement.setInt(1, patientid);
			pstatement.setString(2,patientname);
			pstatement.setInt(3,patientage);
			pstatement.setString(4,bloodgroup);
			pstatement.setString(5,mobileno);
			pstatement.setString(6,state);
			pstatement.setString(7,city);
			pstatement.setString(8,country);
			pstatement.setInt(9,pinno);
			pstatement.setString(10,password);
			pstatement.setString(11, aadhaarno);
			pstatement.setString(12, email);
			pstatement.executeUpdate();
			out.println("<h1>RECORD UPDATED SUCCESSFULLY</h1>");
		}
		catch(ClassNotFoundException e)
		{
			System.out.println(e);
		}
		catch(SQLException d)
		{
			System.out.println(d);
		}
	}

}
