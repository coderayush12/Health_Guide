import java.io.*;



import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.*;
/**
 * Servlet implementation class pr8
 */
public class pr8 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public pr8() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		try 
		{
			out.println("<html>");
			out.println("<head>");
			out.println("<title>DISPLAY PATIENTS</title>");
			out.println("</head>");
			out.println("<body>");
			String st="select * from patient where city=?;";
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/pas?characterEncoding=utf8";
			Connection conn=DriverManager.getConnection(url,"root","abcde");
			PreparedStatement pstatement=conn.prepareStatement(st);
			String city=request.getParameter("city");
			pstatement.setString(1,city);
			ResultSet rs=pstatement.executeQuery();
			int pid,pinno,page;
			String pname,bloodgroup,state,country,password,aadhaarno,emailid,mobileno;
			out.println("<br><br>");
			out.println("<h1 style='color:purple;background-color:yellow;width:470px;'>DISPLAY PATIENT'S DETAILS</h1>");
			out.println("<br>");
			out.println("<table style='width:100%;'>");
			out.println("<tr><th style='color:white;background-color:black;'>"+"patientid"+"</th><th style='color:white;background-color:black;'>"+"patientname"+"</th><th style='color:white;background-color:black;'>"+"patientage"+"</th><th style='color:white;background-color:black;'>"+"bloodgroup"+"</th><th style='color:white;background-color:black;'>"+"emailid"+"</th><th style='color:white;background-color:black;'>"+"mobileno"+"</th><th style='color:white;background-color:black;'>"+"state"+"</th><th style='color:white;background-color:black;'>"+"city"+"</th><th style='color:white;background-color:black;'>"+"country"+"</th><th style='color:white;background-color:black;'>"+"pinno"+"</th><th style='color:white;background-color:black;'>"+"password"+"</th><th style='color:white;background-color:black;'>"+"aadhaarno"+"</th></tr>");
			while(rs.next())
			{
				pid=rs.getInt("patientid");
				pname=rs.getString("patientname");
				page=rs.getInt("patientage");
				bloodgroup=rs.getString("bloodgroup");
				emailid=rs.getString("emailid");
				mobileno=rs.getString("mobileno");
				state=rs.getString("state");
				city=rs.getString("city");
				country=rs.getString("country");
				pinno=rs.getInt("pinno");
				password=rs.getString("password");
				aadhaarno=rs.getString("aadhaarno");
				out.println("<br>");
				out.println("<tr><td style='color:purple;background-color:yellow;'>&emsp;"+pid+"</td><td style='color:purple;background-color:yellow;'>&emsp;"+pname+"</td><td style='color:purple;background-color:yellow;'>&emsp;"+page+"</td><td style='color:purple;background-color:yellow;'>&emsp;"+bloodgroup+"</td><td style='color:purple;background-color:yellow;'>&emsp;"+emailid+"</td><td style='color:purple;background-color:yellow;'>&emsp;"+mobileno+"</td><td style='color:purple;background-color:yellow;'>&emsp;"+state+"</td><td style='color:purple;background-color:yellow;'>&emsp;"+city+"</td><td style='color:purple;background-color:yellow;'>&emsp;"+country+"</td><td style='color:purple;background-color:yellow;'>&emsp;"+pinno+"</td><td style='color:purple;background-color:yellow;'>&emsp;"+password+"</td><td style='color:purple;background-color:yellow;'>&emsp;"+aadhaarno+"</td></tr>");
				out.println("<br>");				
			}
			out.println("</table>");
		}
		catch(ClassNotFoundException e)
		{
			System.out.println(e);
		}
		catch(SQLException d)
		{
			System.out.println(d);
		}
		out.println("</body>");
		out.println("</html>");
	}

}
