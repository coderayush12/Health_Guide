import java.io.*;


import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.sql.*;
/**
 * Servlet implementation class pro6
 */
public class pro6 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public pro6() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		HttpSession session=request.getSession(true);
		if(request.getParameter("View")!=null)
		{
			try
			{
				String st="select * from doctor where emailid=?;";
				Class.forName("com.mysql.cj.jdbc.Driver");
				String url="jdbc:mysql://localhost:3306/pas?characterEncoding=utf8";
				Connection conn=DriverManager.getConnection(url,"root","abcde");
				PreparedStatement pstatement=conn.prepareStatement(st);
				String email=String.valueOf(session.getAttribute("email"));
				pstatement.setString(1, email);
				ResultSet rs=pstatement.executeQuery();
				int did,exp,pinno;
				String dname,degree,spc,dage,address,state,city,country,mob,currworkin,workaddress,password,identno;
				out.println("<html>");
				out.println("<head><title>VIEW DETAILS</title></head>");
				out.println("<body>");
				out.println("<br><br>");
				out.println("<h1 style='color:purple;background-color:yellow;width:320px;'>Display Doctor Details</h1>");
				out.println("<table style='width:100%;'>");
				out.println("<tr><th style='color:white;background-color:black;'>"+"doctorid"+"</th><th style='color:white;background-color:black;'>"+"doctorname"+"</th><th style='color:white;background-color:black;'>"+"doctorage"+"</th><th style='color:white;background-color:black;'>"+"degree"+"</th><th style='color:white;background-color:black;'>"+"specialization"+"</th><th style='color:white;background-color:black;'>"+"experience"+"</th><th style='color:white;background-color:black;'>"+"address"+"</th><th style='color:white;background-color:black;'>"+"state"+"</th><th style='color:white;background-color:black;'>"+"city"+"</th><th style='color:white;background-color:black;'>"+"country"+"</th><th style='color:white;background-color:black;'>"+"emailid"+"</th><th style='color:white;background-color:black;'>"+"mobileno"+"</th><th style='color:white;background-color:black;'>"+"currentlyworkingin"+"</th><th style='color:white;background-color:black;'>"+"workingaddress"+"</th><th style='color:white;background-color:black;'>"+"pinno"+"</th><th style='color:white;background-color:black;'>"+"password"+"</th><th style='color:white;background-color:black;'>"+"identificationno"+"</th></tr>");
				while(rs.next())
				{
					did=rs.getInt("doctorid");
					dname=rs.getString("doctorname");
					dage=rs.getString("doctorage");
					degree=rs.getString("degree");
					spc=rs.getString("specialization");
					exp=rs.getInt("experience");
					address=rs.getString("address");
					state=rs.getString("state");
					city=rs.getString("city");
					country=rs.getString("country");
					email=rs.getString("emailid");
					mob=rs.getString("mobileno");
					currworkin=rs.getString("currently_working_in");
					workaddress=rs.getString("working_address");
					pinno=rs.getInt("pinno");
					password=rs.getString("password");
					identno=rs.getString("identificationno");
					out.println("<tr><td style='color:purple;background-color:yellow;'>"+did+"</td><td style='color:purple;background-color:yellow;'>"+dname+"</td><td style='color:purple;background-color:yellow;'>"+dage+"</td><td style='color:purple;background-color:yellow;'>"+degree+"</td><td style='color:purple;background-color:yellow;'>"+spc+"</td><td style='color:purple;background-color:yellow;'>"+exp+"</td><td style='color:purple;background-color:yellow;'>"+address+"</td><td style='color:purple;background-color:yellow;'>"+state+"</td><td style='color:purple;background-color:yellow;'>"+city+"</td><td style='color:purple;background-color:yellow;'>"+country+"</td><td style='color:purple;background-color:yellow;'>"+email+"</td><td style='color:purple;background-color:yellow;'>"+mob+"</td><td style='color:purple;background-color:yellow;'>"+currworkin+"</td><td style='color:purple;background-color:yellow;'>"+workaddress+"</td><td style='color:purple;background-color:yellow;'>"+pinno+"</td><td style='color:purple;background-color:yellow;'>"+password+"</td><td style='color:purple;background-color:yellow;'>"+identno+"</td></tr>");
					out.println("<br>");
				}
				out.println("</table>");
			}
			catch(ClassNotFoundException d)
			{
				System.out.println(d);
			}
			catch(SQLException e)
			{
				System.out.println(e);
			}
		}
		else if(request.getParameter("Update")!=null)
		{
			response.setContentType("text/html");
			out.println("<html>");
			out.println("<head><title>UPDATE DETAILS</title></head>");
			out.println("<body>");
			out.println("<form method='post' action='pro3'>");
			int pinno=0,experience=0,did=0;
			String dname="",dage="",degree="",specialization="",address="",state="",city="",country="",emailid="",mobileno="",currentlyworkingin="",workingaddress="",password="",identificationno="";
			try
			{
				String st="select * from doctor where emailid=?;";
				Class.forName("com.mysql.jdbc.Driver");
				String url="jdbc:mysql://localhost:3306/pas?characterEncoding=utf8";
				Connection conn=DriverManager.getConnection(url,"root","abcde");
				PreparedStatement pstatement=conn.prepareStatement(st);
				String email=String.valueOf(session.getAttribute("email"));
				pstatement.setString(1, email);
				ResultSet rs=pstatement.executeQuery();
				while(rs.next())
				{
					did=rs.getInt("doctorid");
					dname=rs.getString("doctorname");
					dage=rs.getString("doctorage");
					degree=rs.getString("degree");
					specialization=rs.getString("specialization");
					experience=rs.getInt("experience");
					address=rs.getString("address");
					state=rs.getString("state");
					city=rs.getString("city");
					country=rs.getString("country");
					emailid=rs.getString("emailid");
					mobileno=rs.getString("mobileno");
					currentlyworkingin=rs.getString("currently_working_in");
					workingaddress=rs.getString("working_address");
					pinno=rs.getInt("pinno");
					password=rs.getString("password");
					identificationno=rs.getString("identificationno");
				}
				out.println("<br><br>");
				out.println("<h1 style='color:purple;background-color:yellow;width:320px;'>Update Doctor Details</h1>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>doctorid</label>");
				out.println("<label style='color:red;'>*</label>");
				out.println("&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;");
				out.println("<input type='text' name='drid' value="+did+" required>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>doctorname</label>");
				out.println("<label style='color:red;'>*</label>");
				out.println("&emsp;&emsp;&emsp;&emsp;&nbsp;");
				out.println("<input type='text' name='dname' value="+dname+" required>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>doctorage</label>");
				out.println("<label style='color:red;'>*</label>");
				out.println("&emsp;&emsp;&emsp;&emsp;&emsp;");
				out.println("<input type='text' name='dage' value="+dage+" required>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>degree</label>");
				out.println("<label style='color:red;'>*</label>");
				out.println("&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;");
				out.println("<input type='text' name='degree' value="+degree+" required>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>specialization</label>");
				out.println("<label style='color:red;'>*</label>");
				out.println("&emsp;&emsp;&emsp;&nbsp;");
				out.println("<input type='text' name='spc' value="+specialization+" required>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>experience</label>");
				out.println("<label style='color:red;'>*</label>");
				out.println("&emsp;&emsp;&emsp;&emsp;&ensp;");
				out.println("<input type='text' name='exp' value="+experience+" required>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>address</label>");
				out.println("<label style='color:red;'>*</label>");
				out.println("&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;&nbsp;");
				out.println("<input type='text' name='address' value="+address+" required>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>state</label>");
				out.println("<label style='color:red;'>*</label>");
				out.println("&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;");
				out.println("<input type='text' name='state' value="+state+" required>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>city</label>");
				out.println("<label style='color:red;'>*</label>");
				out.println("&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;");
				out.println("<input type='text' name='city' value="+city+" required>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>country</label>");
				out.println("<label style='color:red;'>*</label>");
				out.println("&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;&nbsp;");
				out.println("<input type='text' name='country' value="+country+" required>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>emailid</label>");
				out.println("<label style='color:red;'>*</label>");
				out.println("&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;&nbsp;");
				out.println("<input type='text' name='email' value="+emailid+" required>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>mobileno</label>");
				out.println("<label style='color:red;'>*</label>");
				out.println("&emsp;&emsp;&emsp;&emsp;&emsp;");
				out.println("<input type='text' name='mob' value="+mobileno+" required>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>currentlyworkingin</label>");
				out.println("<label style='color:red;'>*</label>");
				out.println("&emsp;");
				out.println("<input type='text' name='work' value="+currentlyworkingin+" required>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>workingaddress</label>");
				out.println("<label style='color:red;'>*</label>");
				out.println("&emsp;&emsp;&ensp;");
				out.println("<input type='text' name='waddress' value="+workingaddress+" required>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>pinno</label>");
				out.println("<label style='color:red;'>*</label>");
				out.println("&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;");
				out.println("<input type='text' name='pinno' value="+pinno+" required>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>password</label>");
				out.println("<label style='color:red;'>*</label>");
				out.println("&emsp;&emsp;&emsp;&emsp;&emsp;");
				out.println("<input type='text' name='password' value="+password+" required>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>identificationno</label>");
				out.println("<label style='color:red;'>*</label>");
				out.println("&emsp;&emsp;&ensp;");
				out.println("<input type='text' name='ident' value="+identificationno+" required>");
				out.println("<br><br>");
				out.println("<input type='submit' name='Update' value='Update' style='color:white;background-color:purple;'>");
				
			}
			catch(ClassNotFoundException e)
			{
				System.out.println(e);
			}
			catch(SQLException d)
			{
				System.out.println(d);
			}
		}
		else if(request.getParameter("Search")!=null)
		{
			response.sendRedirect("pro5.html");
		}
		
	}

}
