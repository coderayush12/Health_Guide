import java.io.*;


import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.*;
/**
 * Servlet implementation class pro1
 */
public class pro1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public pro1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		try
		{
			
			
			if(request.getParameter("Register")!=null)
			{
				String st="insert into doctor values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
				Class.forName("com.mysql.cj.jdbc.Driver");
				String url="jdbc:mysql://localhost:3306/pas?characterEncoding=utf8";
				Connection conn=DriverManager.getConnection(url,"root","abcde");
				PreparedStatement pstatement=conn.prepareStatement(st);
				int doctorid=Integer.parseInt(request.getParameter("did"));
				String doctorname=request.getParameter("dname");
				String doctorage=request.getParameter("dage");
				String degree=request.getParameter("degree");
				String specialization=request.getParameter("spc");
				int experience=Integer.parseInt(request.getParameter("exp"));
				String address=request.getParameter("address");
				String state=request.getParameter("state");
				String city=request.getParameter("city");
				String country=request.getParameter("country");
				String emailid=request.getParameter("emailid");
				String mobileno=request.getParameter("mobileno");
				String currentlyworkingin=request.getParameter("work");
				String workingaddress=request.getParameter("waddress");
				int pinno=Integer.parseInt(request.getParameter("pinno"));
				String password=request.getParameter("password");
				String identificationno=request.getParameter("ident");
				pstatement.setInt(1,doctorid);
				pstatement.setString(2,doctorname);
				pstatement.setString(3,doctorage);
				pstatement.setString(4, degree);
				pstatement.setString(5, specialization);
				pstatement.setInt(6, experience);
				pstatement.setString(7, address);
				pstatement.setString(8, state);
				pstatement.setString(9, city);
				pstatement.setString(10, country);
				pstatement.setString(11, emailid);
				pstatement.setString(12, mobileno);
				pstatement.setString(13, currentlyworkingin);
				pstatement.setString(14, workingaddress);
				pstatement.setInt(15, pinno);
				pstatement.setString(16, password);
				pstatement.setString(17, identificationno);
				pstatement.executeUpdate();
				out.println("<html>");
				out.println("<body>");
				out.println("<h1>RECORD INSERTED SUCCESSFULLY</h1>");
			}
			
			else if(request.getParameter("Login")!=null)
			{
				response.sendRedirect("pro3.html");
			}
		}
		catch(ClassNotFoundException e)
		{
			System.out.println(e);
		}
		catch(SQLException d)
		{
			System.out.println(d);
		}
		out.println("</body>");
		out.println("</html>");
	}

}
