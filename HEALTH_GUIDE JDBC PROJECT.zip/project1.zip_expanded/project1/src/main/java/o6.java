import java.io.*;


import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.*;
/**
 * Servlet implementation class o6
 */
public class o6 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public o6() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		try
		{
			if(request.getParameter("Update")!=null)
			{
				String st="update otherusers set id=?,firmname=?,mobileno=?,address=?,city=?,state=?,country=?,firmtype=?,pinno=?,password=?,firmno=? where email=?;";
				Class.forName("com.mysql.cj.jdbc.Driver");
				String url="jdbc:mysql://localhost:3306/pas?characterEncoding=utf8";
				Connection conn=DriverManager.getConnection(url,"root","abcde");
				PreparedStatement pstatement=conn.prepareStatement(st);
				int id=Integer.parseInt(request.getParameter("fid"));
				String fname=request.getParameter("fname");
				String mob=request.getParameter("mob");
				String address=request.getParameter("address");
				String city=request.getParameter("city");
				String state=request.getParameter("state");
				String country=request.getParameter("country");
				String ftype=request.getParameter("ftype");
				int pinno=Integer.parseInt(request.getParameter("pinno"));
				String password=request.getParameter("password");
				String fno=request.getParameter("fno");
				String email=request.getParameter("email");
				pstatement.setInt(1, id);
				pstatement.setString(2, fname);
				pstatement.setString(3, mob);
				pstatement.setString(4, address);
				pstatement.setString(5, city);
				pstatement.setString(6, state);
				pstatement.setString(7, country);
				pstatement.setString(8, ftype);
				pstatement.setInt(9, pinno);
				pstatement.setString(10, password);
				pstatement.setString(11, fno);
				pstatement.setString(12, email);
				pstatement.executeUpdate();
				out.println("<html>");
				out.println("<body>");
				out.println("<h1>RECORD UPDATED SUCCESSFULLY</h1>");
				out.println("</body>");
				out.println("</html>");
			}
			
		}
		catch(SQLException e)
		{
			System.out.println(e);
		}
		catch(ClassNotFoundException d)
		{
			System.out.println(d);
		}
	}

}
