import java.io.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.*;

/**
 * Servlet implementation class pro8
 */
public class pro8 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public pro8() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		out.println("<html>");
		out.println("<body>");
		out.println("<form method='post' action='pro9'>");
		if(request.getParameter("InsertPrescription")!=null) {
			try 
			{
				String dname="",pres="",medicine="",medicinedose="",date="";
				HttpSession session=request.getSession(true);
				String pid=String.valueOf(request.getParameter("paid"));
				String st="select * from patient;";
				Class.forName("com.mysql.cj.jdbc.Driver");
				String url="jdbc:mysql://localhost:3306/pas?characterEncoding=utf8";
				Connection conn=DriverManager.getConnection(url,"root","abcde");
				PreparedStatement pstatement=conn.prepareStatement(st);
				pstatement.execute();
				out.println("<head><title>INSERT PRESCRIPTIONS</title></head>");
				out.println("<br><br>");
				out.println("<h1 style='color:purple;background-color:yellow;width:420px;'>INSERT PRESCRIPTIONS</h1>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>Patient id</label>");
				out.println("<label style='color:red;'>*</label>");
				out.println("&emsp;&emsp;&emsp;");
				out.println("<input type='text' name='ptid' value="+pid+" style='width:205px;' required>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>Prescription Id</label>");
				out.println("<label style='color:red;'>*</label>");
				out.println("&emsp;");
				out.println("<input type='text' name='prid' style='width:205px;'>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>Disease Name</label>");
				out.println("<label style='color:red;'>*</label>");
				out.println("&emsp;");
				out.println("<textarea rows='2' cols='25' name='Dname' required></textarea>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>Prescription</label>");
				out.println("<label style='color:red;'>*</label>");
				out.println("&emsp;&emsp;");
				out.println("<textarea rows='2' cols='25' name='Pres' required></textarea>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>Medicine</label>");
				out.println("<label style='color:red;'>*</label>");
				out.println("&emsp;&emsp;&emsp;");
				out.println("<textarea rows='2' cols='25' name='Med' required></textarea>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>Medicine Dose</label>");
				out.println("<label style='color:red;'>*</label>");
				out.println("&emsp;");
				out.println("<textarea rows='2' cols='25' name='Dose' required></textarea>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>Date</label>");
				out.println("<label style='color:red;'>*</label>");
				out.println("&emsp;&emsp;&emsp;&emsp;&emsp;");
				out.println("<input type='date' name='Date' style='width:205px;' required>");
				out.println("<br><br>");
				out.println("<input type='submit' name='AddAPrescription' value='AddAPrescription' style='color:white;background-color:purple;'>");
				session.setAttribute("paid",pid);
				session.setAttribute("Dname", dname);
				session.setAttribute("Pres", pres);
				session.setAttribute("Med", medicine);
				session.setAttribute("Dose", medicinedose);
				session.setAttribute("Date", date);
			}
				
			catch(SQLException e)
			{
				System.out.println(e);
			}
			catch(ClassNotFoundException d)
			{
				System.out.println(d);
			}
		}
		else if(request.getParameter("ViewOpenPrescription")!=null)
		{
			try
			{
				String rid=null;
				String pid=request.getParameter("paid");
				String dname=request.getParameter("Dname");
				String prescriptions=request.getParameter("Pres");
				String medicine=request.getParameter("Med");
				String medicinedose=request.getParameter("Dose");
				String date=request.getParameter("Date");
				String prescriptionid=request.getParameter("prid");
				String st="select * from prescription where patientid=?;";
				Class.forName("com.mysql.jdbc.Driver");
				String url="jdbc:mysql://localhost:3306/pas?characterEncoding=utf8";
				Connection conn=DriverManager.getConnection(url,"root","abcde");
				PreparedStatement pstatement=conn.prepareStatement(st);
				pstatement.setString(1,pid);
				ResultSet rs=pstatement.executeQuery();
				out.println("<head><title>VIEW OPEN PRESCRIPTIONS</title></head>");
				out.println("<br><br>");
				out.println("<h1 style='color:purple;background-color:yellow;width:530px;'>DISPLAY OPEN PRESCRIPTIONS</h1>");
				out.println("<table style='width:100%;'>");
				out.println("<tr style='color:white;background-color:black;'><th>"+"RecordId"+"</th><th>&emsp;"+"PatientId"+"</th><th>&emsp;"+"diseasename"+"</th><th>&emsp;"+"prescriptions"+"</th><th>&emsp;"+"medicine"+"</th><th>&emsp;"+"medicinedose"+"</th><th>&emsp;"+"date"+"</th><th>&emsp;"+"PresciptionId"+"</th></tr>");
				while(rs.next())
				{
					rid=rs.getString("recordid");
					prescriptionid=rs.getString("prescriptionid");
					pid=rs.getString("patientid");
					dname=rs.getString("diseasename");
					prescriptions=rs.getString("prescription");
					medicine=rs.getString("medicine");
					medicinedose=rs.getString("medicinedose");
					date=rs.getString("date");
					out.println("<br>");
					out.println("<tr style='color:purple;background-color:yellow;'><td>&emsp;"+rid+"</td><td>&emsp;&ensp;"+pid+"</td><td>&emsp;"+dname+"</td><td>&emsp;"+prescriptions+"</td><td>&emsp;"+medicine+"</td><td>&emsp;"+medicinedose+"</td><td>&emsp;"+date+"</td><td>&emsp;&ensp;"+prescriptionid+"</td></tr>");
				}
				out.println("</table>");
			}
			catch(SQLException e) {
				System.out.println(e);
			}
			catch(ClassNotFoundException d)
			{
				System.out.println(d);
			}
		}
		else if(request.getParameter("ViewClosedPrescription")!=null) {
			try
			{
				String prescriptionid=null;
				String pid=request.getParameter("paid");
				String dname=request.getParameter("Dname");
				String prescription=request.getParameter("Pres");
				String medicine=request.getParameter("Med");
				String medicinedose=request.getParameter("Dose");
				String date=request.getParameter("Date");
				String st="select * from close where patientid=?;";
				Class.forName("com.mysql.jdbc.Driver");
				String url="jdbc:mysql://localhost:3306/pas?characterEncoding=utf8";
				Connection conn=DriverManager.getConnection(url,"root","abcde");
				PreparedStatement pstatement=conn.prepareStatement(st);
				pstatement.setString(1, pid);
				ResultSet rs=pstatement.executeQuery();
				out.println("<head><title>VIEW CLOSED PRESCRIPTIONS</title></head>");
				out.println("<br><br>");
				out.println("<h1 style='color:purple;background-color:yellow;width:550px;'>DISPLAY CLOSED PRESCRIPTIONS</h1>");
				out.println("<table style='width:100%;'>");
				out.println("<tr style='color:white;background-color:black;'><th>"+"PrescriptionId"+"</th><th>&emsp;"+"PatientId"+"</th><th>&emsp;"+"diseasename"+"</th><th>&emsp;"+"prescriptions"+"</th><th>&emsp;"+"medicine"+"</th><th>&emsp;"+"medicinedose"+"</th><th>&emsp;"+"date"+"</th></tr>");
				while(rs.next()) {
					pid=rs.getString("patientid");
					prescriptionid=rs.getString("prescriptionid");
					dname=rs.getString("diseasename");
					prescription=rs.getString("prescription");
					medicine=rs.getString("medicine");
					medicinedose=rs.getString("medicinedose");
					date=rs.getString("date");
					out.println("<br>");
					out.println("<tr style='color:purple;background-color:yellow;'><td>&emsp;"+prescriptionid+"</td><td>&emsp;"+pid+"</td><td>&emsp;"+dname+"</td><td>&emsp;"+prescription+"</td><td>&emsp;"+medicine+"</td><td>&emsp;"+medicinedose+"</td><td>&emsp;"+date+"</td></tr>");
				}
				out.println("<table>");
			}
			catch(SQLException e) {
				System.out.println(e);
			}
			catch(ClassNotFoundException d) {
				System.out.println(d);
			}
		}
		else if(request.getParameter("SearchOpenPrescription")!=null)
		{
			try
			{
				out.println("<head>");
				out.println("<title>ENTER DETAILS</title>");
				out.println("</head>");
				String st="select * from prescription;";
				Class.forName("com.mysql.jdbc.Driver");
				String url="jdbc:mysql://localhost:3306/pas?characterEncoding=utf8";
				Connection conn=DriverManager.getConnection(url,"root","abcde");
				PreparedStatement pstatement=conn.prepareStatement(st);
				pstatement.execute();
				out.println("<br>");
				out.println("<h1 style='color:purple;background-color:yellow;width:420;'>Enter Patient's PrescriptionId</h1>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>Prescription Id</label>");
				out.println("<label style='color:red;'>*</label>");
				out.println("&emsp;");
				out.println("<input type='text' name='prid' >&emsp;");
				out.println("<input type='submit' name='SearchOpenPrescription' value='SearchOpenPrescription' style='color:white;background-color:purple;'>");
				out.println("<br><br>");
				out.println("<h1 style='color:purple;background-color:yellow;width:300;'>Enter Patient's Date</h1>");
				out.println("<br><br>");
				out.println("&ensp;<label style='color:white;background-color:black;'>Date</label>");
				out.println("<label style='color:red;'>*</label>");
				out.println("&emsp;&emsp;&ensp;");
				out.println("<input type='text' name='date'>&emsp;");
				out.println("<input type='submit' name='SearchOpenPrescriptionByDate' value='SearchOpenPrescriptionByDate' style='color:white;background-color:purple;'>");
			}
			catch(SQLException e)
			{
				System.out.println(e);
			}
			catch(ClassNotFoundException d)
			{
				System.out.println(d);
			}
		}
		else if(request.getParameter("SearchClosedPrescription")!=null)
		{
			try
			{
				out.println("<head>");
				out.println("<title>ENTER DETAILS</title>");
				out.println("</head>");
				String st="select * from close;";
				Class.forName("com.mysql.jdbc.Driver");
				String url="jdbc:mysql://localhost:3306/pas?characterEncoding=utf8";
				Connection conn=DriverManager.getConnection(url,"root","abcde");
				PreparedStatement pstatement=conn.prepareStatement(st);
				pstatement.execute();
				out.println("<br>");
				out.println("<h1 style='color:purple;background-color:yellow;width:420;'>Enter Patient's PrescriptionId</h1>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>Prescription Id</label>");
				out.println("<label style='color:red;'>*</label>");
				out.println("&emsp;");
				out.println("<input type='text' name='prid' >&emsp;");
				out.println("<input type='submit' name='SearchClosedPrescription' value='SearchClosedPrescription' style='color:white;background-color:purple;'>");
				out.println("<br><br>");
				out.println("<h1 style='color:purple;background-color:yellow;width:300;'>Enter Patient's Date</h1>");
				out.println("<br><br>");
				out.println("&ensp;<label style='color:white;background-color:black;'>Date</label>");
				out.println("<label style='color:red;'>*</label>");
				out.println("&emsp;&emsp;&ensp;");
				out.println("<input type='text' name='date'>&emsp;");
				out.println("<input type='submit' name='SearchClosedPrescriptionByDate' value='SearchClosedPrescriptionByDate' style='color:white;background-color:purple;'>");
			}
			catch(SQLException e)
			{
				System.out.println(e);
			}
			catch(ClassNotFoundException d)
			{
				System.out.println(d);
			}
		}
		else if(request.getParameter("ClosePrescription")!=null) 
		{
			try
			{
				out.println("<html>");
				out.println("<head>");
				out.println("<title>CLOSE PRESCRIPTIONS</title>");
				out.println("</head>");
				out.println("<body>");
				String st="select * from prescription;";
				Class.forName("com.mysql.jdbc.Driver");
				String url="jdbc:mysql://localhost:3306/pas?characterEncoding=utf8";
				Connection conn=DriverManager.getConnection(url,"root","abcde");
				PreparedStatement pstatement=conn.prepareStatement(st);
				pstatement.execute();
				out.println("<br>");
				out.println("<h1 style='color:purple;background-color:yellow;width:420;'>Enter Patient's PrescriptionId</h1>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>Prescription Id</label>");
				out.println("<label style='color:red;'>*</label>");
				out.println("&emsp;");
				out.println("<input type='text' name='prid'>&emsp;");
				out.println("<input type='submit' name='Close' value='Close' style='color:white;background-color:purple'>");
				
			}
			catch(SQLException e)
			{
				System.out.println(e);
			}
			catch(ClassNotFoundException d) {
				System.out.println(d);
			}
		}
		out.println("</form>");
		out.println("</body>");
		out.println("</html>");
			
	}

		
}
