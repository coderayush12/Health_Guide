import java.io.*;



import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.*;
/**
 * Servlet implementation class o1
 */
public class o1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public o1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		out.println("<html>");
		out.println("<body>");
		try
		{
			if(request.getParameter("Register")!=null)
			{
				String st="insert into otherusers values(?,?,?,?,?,?,?,?,?,?,?,?);";
				Class.forName("com.mysql.cj.jdbc.Driver");
				String url="jdbc:mysql://localhost:3306/pas?characterEncoding=utf8";
				Connection conn=DriverManager.getConnection(url,"root","abcde");
				PreparedStatement pstatement=conn.prepareStatement(st);
				int id=Integer.parseInt(request.getParameter("oid"));
				String fname=request.getParameter("oname");
				String email=request.getParameter("email");
				String mob=request.getParameter("mob");
				String address=request.getParameter("address");
				String city=request.getParameter("city");
				String state=request.getParameter("state");
				String country=request.getParameter("country");
				String ftype=request.getParameter("ftype");
				int pinno=Integer.parseInt(request.getParameter("pin"));
				String password=request.getParameter("password");
				String fno=request.getParameter("fno");
				pstatement.setInt(1, id);
				pstatement.setString(2, fname);
				pstatement.setString(3, email);
				pstatement.setString(4, mob);
				pstatement.setString(5, address);
				pstatement.setString(6, city);
				pstatement.setString(7, state);
				pstatement.setString(8, country);
				pstatement.setString(9, ftype);
				pstatement.setInt(10, pinno);
				pstatement.setString(11, password);
				pstatement.setString(12, fno);
				pstatement.executeUpdate();
				out.println("<h1>RECORD INSERTED SUCCESSFULLY</h1>");
			}
			else if(request.getParameter("Login")!=null)
			{
				response.sendRedirect("o2.html");
			}
		}
		catch(SQLException e)
		{
			System.out.println(e);
		}
		catch(ClassNotFoundException d)
		{
			System.out.println(d);
		}
		out.println("</body>");
		out.println("</html>");
	}

}
