import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.sql.*;

/**
 * Servlet implementation class pro11
 */
public class pro11 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public pro11() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		HttpSession session=request.getSession(true);
		try
		{
			String st="insert into close values(?,?,?,?,?,?,?);";
			String st1="delete from prescription where prescriptionid=?;";
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/pas?characterEncoding=utf8";
			Connection conn=DriverManager.getConnection(url,"root","abcde");
			PreparedStatement pstatement=conn.prepareStatement(st);
			PreparedStatement pstatement2=conn.prepareStatement(st1);
			String date=String.valueOf(session.getAttribute("date"));
			String patientid=String.valueOf(session.getAttribute("patientid"));
			String dname=String.valueOf(session.getAttribute("dname"));
			String prescription=String.valueOf(session.getAttribute("prescription"));
			String medicine=String.valueOf(session.getAttribute("medicine"));
			String medicinedose=String.valueOf(session.getAttribute("medicinedose"));
			String prescriptionid=String.valueOf(session.getAttribute("prescriptionid"));
			pstatement.setString(1, prescriptionid);
			pstatement.setString(2, patientid);
			pstatement.setString(3, dname);
			pstatement2.setString(1, prescriptionid);
			pstatement.setString(4, prescription);
			pstatement.setString(5, medicine);
			pstatement.setString(6, medicinedose);
			pstatement.setString(7, date);
			pstatement.executeUpdate();
			pstatement2.executeUpdate();
			out.println("<html>");
			out.println("<head>");
			out.println("<title>CLOSE PRESCRIPTION</title>");
			out.println("</head>");
			out.println("<body>");
			out.println("<h1>PRESCRIPTION CLOSED SUCCESSFULLY</h1>");
			out.println("</body>");
			out.println("</html>");
		}
		catch(ClassNotFoundException d)
		{
			System.out.println(d);
		}
		catch(SQLException e)
		{
			System.out.println(e);
		}
	}

}
