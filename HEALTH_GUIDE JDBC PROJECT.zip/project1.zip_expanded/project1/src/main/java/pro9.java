import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.*;
/**
 * Servlet implementation class pro9
 */
public class pro9 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public pro9() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		HttpSession session=request.getSession(true);
		try
		{
			if(request.getParameter("AddAPrescription")!=null)
			{
			    out.println("<html><body>");

			    int prid = Integer.parseInt(request.getParameter("prid"));
			    int pid  = Integer.parseInt(request.getParameter("ptid"));
			    String dname = request.getParameter("Dname");
			    String prescription = request.getParameter("Pres");
			    String medicine = request.getParameter("Med");
			    String medicinedose = request.getParameter("Dose");
			    String date = request.getParameter("Date"); // YYYY-MM-DD

			    String st = "INSERT INTO prescription " +
			                "(prescriptionid, patientid, diseasename, prescription, medicine, medicinedose, date) " +
			                "VALUES (?,?,?,?,?,?,?)";

			    Class.forName("com.mysql.cj.jdbc.Driver");
			    Connection conn = DriverManager.getConnection(
			            "jdbc:mysql://localhost:3306/pas?characterEncoding=utf8",
			            "root","abcde");

			    PreparedStatement ps = conn.prepareStatement(st);

			    ps.setInt(1, prid);
			    ps.setInt(2, pid);
			    ps.setString(3, dname);
			    ps.setString(4, prescription);
			    ps.setString(5, medicine);
			    ps.setString(6, medicinedose);
			    ps.setDate(7, java.sql.Date.valueOf(date));

			    ps.executeUpdate();

			    out.println("<h1>PRESCRIPTION ADDED SUCCESSFULLY</h1>");

			    ps.close();
			    conn.close();
			}
			else if(request.getParameter("SearchOpenPrescription")!=null)
			{
				out.println("<html>");
				out.println("<head>");
				out.println("<title>SEARCH OEPNPRESCRIPTIONS BY PRESCRIPTIONID</title>");
				out.println("</head>");
				out.println("<body>");
				String st="select * from prescription where prescriptionid=?;";
				Class.forName("com.mysql.jdbc.Driver");
				String url="jdbc:mysql://localhost:3306/pas?characterEncoding=utf8";
				Connection conn=DriverManager.getConnection(url,"root","abcde");
				PreparedStatement pstatement=conn.prepareStatement(st);
				String date=request.getParameter("date");
				String prescriptionid=request.getParameter("prid");
				String patientid=String.valueOf(session.getAttribute("pid"));
				String dname=String.valueOf(session.getAttribute("dname"));
				String prescription=String.valueOf(session.getAttribute("pres"));
				String medicine=String.valueOf(session.getAttribute("medicine"));
				String recordid=null;
				String medicinedose=String.valueOf(session.getAttribute("medicinedose"));
				pstatement.setString(1, prescriptionid);
				ResultSet rs=pstatement.executeQuery();
				out.println("<br><br>");
				out.println("<h1 style='color:purple;background-color:yellow;width:530;'>DISPLAY OPEN PRESCRIPTIONS</h1>");
				out.println("<table style='width:100%;'>");
				out.println("<tr style='color:white;background-color:black;'><th>"+"RecordId"+"</th><th>&emsp;"+"PatientId"+"</th><th>&emsp;"+"DiseaseName"+"</th><th>&emsp;"+"Prescription"+"</th><th>&emsp;"+"Medicine"+"</th><th>&emsp;"+"MedicineDose"+"</th><th>&emsp;"+"Date"+"</th><th>&emsp;"+"PrescriptionId"+"</th></tr>");
				while(rs.next()) {
					recordid=rs.getString("recordid");
					prescriptionid=rs.getString("prescriptionid");
					patientid=rs.getString("patientid");
					dname=rs.getString("diseasename");
					prescription=rs.getString("prescription");
					medicine=rs.getString("medicine");
					medicinedose=rs.getString("medicinedose");
					date=rs.getString("date");
					out.println("<tr style='color:purple;background-color:yellow;'><td>"+recordid+"</td><td>&emsp;"+patientid+"</td><td>&emsp;"+dname+"</td><td>&emsp;"+prescription+"</td><td>&emsp;"+medicine+"</td><td>&emsp;"+medicinedose+"</td><td>&emsp;"+date+"</td><td>&emsp;"+prescriptionid+"</td></tr>");
					out.println("<br>");
				}
				out.println("</table>");
				
			}
			else if(request.getParameter("SearchOpenPrescriptionByDate")!=null) {
				out.println("<html>");
				out.println("<head>");
				out.println("<title>SEARCH OPENPRESCRIPTION BY DATE</title>");
				out.println("</head>");
				out.println("<body>");
				String st="select * from prescription where date=?;";
				Class.forName("com.mysql.jdbc.Driver");
				String url="jdbc:mysql://localhost:3306/pas?characterEncoding=utf8";
				Connection conn=DriverManager.getConnection(url,"root","abcde");
				PreparedStatement pstatement=conn.prepareStatement(st);
				String date=request.getParameter("date");
				String recordid=null;
				String prescriptionid=request.getParameter("prid");
				String patientid=String.valueOf(session.getAttribute("pid"));
				String dname=String.valueOf(session.getAttribute("dname"));
				String prescription=String.valueOf(session.getAttribute("pres"));
				String medicine=String.valueOf(session.getAttribute("medicine"));
				String medicinedose=String.valueOf(session.getAttribute("medicinedose"));
				pstatement.setString(1, date);
				ResultSet rs=pstatement.executeQuery();
				out.println("<br><br>");
				out.println("<h1 style='color:purple;background-color:yellow;width:530;'>DISPLAY OPEN PRESCRIPTIONS</h1>");
				out.println("<table style='width:100%;'>");
				out.println("<tr style='color:white;background-color:black;'><th>"+"RecordId"+"</th><th>&emsp;"+"PatientId"+"</th><th>&emsp;"+"DiseaseName"+"</th><th>&emsp;"+"Prescription"+"</th><th>&emsp;"+"Medicine"+"</th><th>&emsp;"+"MedicineDose"+"</th><th>&emsp;"+"Date"+"</th><th>&emsp;"+"PrescriptionId"+"</th></tr>");
				while(rs.next()) {
					recordid=rs.getString("recordid");
					patientid=rs.getString("patientid");
					dname=rs.getString("diseasename");
					prescription=rs.getString("prescription");
					medicine=rs.getString("medicine");
					medicinedose=rs.getString("medicinedose");
					date=rs.getString("date");
					prescriptionid=rs.getString("prescriptionid");
					out.println("<tr style='color:purple;background-color:yellow;'><td>"+recordid+"</td><td>&emsp;"+patientid+"</td><td>&emsp;"+dname+"</td><td>&emsp;"+prescription+"</td><td>&emsp;"+medicine+"</td><td>&emsp;"+medicinedose+"</td><td>&emsp;"+date+"</td><td>"+prescriptionid+"</td></tr>");
					out.println("<br>");
				}
				out.println("</table>");
			}
			else if(request.getParameter("SearchClosedPrescription")!=null)
			{
				out.println("<html>");
				out.println("<head>");
				out.println("<title>SEARCH CLOSEDPRESCRIPTIONS BY PRESCRIPTIONID</title>");
				out.println("</head>");
				out.println("<body>");
				String st="select * from close where prescriptionid=?;";
				Class.forName("com.mysql.jdbc.Driver");
				String url="jdbc:mysql://localhost:3306/pas?characterEncoding=utf8";
				Connection conn=DriverManager.getConnection(url,"root","abcde");
				PreparedStatement pstatement=conn.prepareStatement(st);
				String date=request.getParameter("date");
				String prescriptionid=request.getParameter("prid");
				String patientid=String.valueOf(session.getAttribute("pid"));
				String dname=String.valueOf(session.getAttribute("dname"));
				String prescription=String.valueOf(session.getAttribute("pres"));
				String medicine=String.valueOf(session.getAttribute("medicine"));
				String medicinedose=String.valueOf(session.getAttribute("medicinedose"));
				pstatement.setString(1, prescriptionid);
				ResultSet rs=pstatement.executeQuery();
				out.println("<br><br>");
				out.println("<h1 style='color:purple;background-color:yellow;width:580;'>DISPLAY CLOSED PRESCRIPTIONS</h1>");
				out.println("<table style='width:100%;'>");
				out.println("<tr style='color:white;background-color:black;'><th>"+"PatientId"+"</th><th>&emsp;"+"DiseaseName"+"</th><th>&emsp;"+"Prescription"+"</th><th>&emsp;"+"Medicine"+"</th><th>&emsp;"+"MedicineDose"+"</th><th>&emsp;"+"Date"+"</th><th>&emsp;"+"PrescriptionId"+"</th></tr>");
				while(rs.next()) {
					prescriptionid=rs.getString("prescriptionid");
					patientid=rs.getString("patientid");
					dname=rs.getString("diseasename");
					prescription=rs.getString("prescription");
					medicine=rs.getString("medicine");
					medicinedose=rs.getString("medicinedose");
					date=rs.getString("date");
					out.println("<tr style='color:purple;background-color:yellow;'><td>&emsp;"+patientid+"</td><td>&emsp;"+dname+"</td><td>&emsp;"+prescription+"</td><td>&emsp;"+medicine+"</td><td>&emsp;"+medicinedose+"</td><td>&emsp;"+date+"</td><td>&emsp;"+prescriptionid+"</td></tr>");
					out.println("<br>");
				}
				out.println("</table>");
			}
			else if(request.getParameter("SearchClosedPrescriptionByDate")!=null) {
				out.println("<html>");
				out.println("<head>");
				out.println("<title>SEARCH CLOSEDPRESCRIPTION BY DATE</title>");
				out.println("</head>");
				out.println("<body>");
				String st="select * from close where date=?;";
				Class.forName("com.mysql.jdbc.Driver");
				String url="jdbc:mysql://localhost:3306/pas?characterEncoding=utf8";
				Connection conn=DriverManager.getConnection(url,"root","abcde");
				PreparedStatement pstatement=conn.prepareStatement(st);
				String date=request.getParameter("date");
				String prescriptionid=request.getParameter("prid");
				String patientid=String.valueOf(session.getAttribute("pid"));
				String dname=String.valueOf(session.getAttribute("dname"));
				String prescription=String.valueOf(session.getAttribute("pres"));
				String medicine=String.valueOf(session.getAttribute("medicine"));
				String medicinedose=String.valueOf(session.getAttribute("medicinedose"));
				pstatement.setString(1, date);
				ResultSet rs=pstatement.executeQuery();
				out.println("<br><br>");
				out.println("<h1 style='color:purple;background-color:yellow;width:580;'>DISPLAY CLOSED PRESCRIPTIONS</h1>");
				out.println("<table style='width:100%;'>");
				out.println("<tr style='color:white;background-color:black;'><th>"+"PatientId"+"</th><th>&emsp;"+"DiseaseName"+"</th><th>&emsp;"+"Prescription"+"</th><th>&emsp;"+"Medicine"+"</th><th>&emsp;"+"MedicineDose"+"</th><th>&emsp;"+"Date"+"</th><th>&emsp;"+"PrescriptionId"+"</th></tr>");
				while(rs.next()) {
					patientid=rs.getString("patientid");
					dname=rs.getString("diseasename");
					prescription=rs.getString("prescription");
					medicine=rs.getString("medicine");
					medicinedose=rs.getString("medicinedose");
					date=rs.getString("date");
					prescriptionid=rs.getString("prescriptionid");
					out.println("<tr style='color:purple;background-color:yellow;'><td>&emsp;"+patientid+"</td><td>&emsp;"+dname+"</td><td>&emsp;"+prescription+"</td><td>&emsp;"+medicine+"</td><td>&emsp;"+medicinedose+"</td><td>&emsp;"+date+"</td><td>&emsp;"+prescriptionid+"</td></tr>");
					out.println("<br>");
				}
				out.println("</table>");
			}
			else if(request.getParameter("Close")!=null) {
				out.println("<html>");
				out.println("<head>");
				out.println("<title>CLOSE PRESCRIPTIONS</title>");
				out.println("</head>");
				out.println("<form method='post' action='pro11'>");
				out.println("<body>");
				String st="select * from prescription where prescriptionid=?;";
				Class.forName("com.mysql.jdbc.Driver");
				String url="jdbc:mysql://localhost:3306/pas?characterEncoding=utf8";
				Connection conn=DriverManager.getConnection(url,"root","abcde");
				PreparedStatement pstatement=conn.prepareStatement(st);
				String date=String.valueOf(session.getAttribute("date"));
				String rid=null;
				String prescriptionid=request.getParameter("prid");
				String patientid=String.valueOf(session.getAttribute("pid"));
				String dname=String.valueOf(session.getAttribute("dname"));
				String prescription=String.valueOf(session.getAttribute("pres"));
				String medicine=String.valueOf(session.getAttribute("medicine"));
				String medicinedose=String.valueOf(session.getAttribute("medicinedose"));
				pstatement.setString(1, prescriptionid);
				ResultSet rs=pstatement.executeQuery();
				out.println("<br><br>");
				out.println("<h1 style='color:purple;background-color:yellow;width:430px;'>DISPLAY PRESCRIPTIONS</h1>");
				out.println("<table style='width:100%;'>");
				out.println("<tr style='color:white;background-color:black;'><th>"+"RecordId"+"</th><th>&emsp;"+"PatientId"+"</th><th>&emsp;"+"DiseaseName"+"</th><th>&emsp;"+"Prescription"+"</th><th>&emsp;"+"Medicine"+"</th><th>&emsp;"+"MedicineDose"+"</th><th>&emsp;"+"Date"+"</th><th>&emsp;"+"PrescriptionId"+"</th></tr>");
				while(rs.next()) {
					rid=rs.getString("recordid");
					prescriptionid=rs.getString("prescriptionid");
					patientid=rs.getString("patientid");
					dname=rs.getString("diseasename");
					prescription=rs.getString("prescription");
					medicine=rs.getString("medicine");
					medicinedose=rs.getString("medicinedose");
					date=rs.getString("date");
					out.println("<tr style='color:purple;background-color:yellow;'><td>"+rid+"</td><td>&emsp;"+patientid+"</td><td>&emsp;"+dname+"</td><td>&emsp;"+prescription+"</td><td>&emsp;"+medicine+"</td><td>&emsp;"+medicinedose+"</td><td>&emsp;"+date+"</td><td>"+prescriptionid+"</td></tr>");
					out.println("<br>");
				}
				out.println("</table>");
				out.println("<br><br>");
				out.println("<input type='submit' name='Close' value='Close' style='color:white;background-color:purple'>");
				session.setAttribute("patientid",patientid);
				session.setAttribute("rid",rid);
				session.setAttribute("dname", dname);
				session.setAttribute("prescription", prescription);
				session.setAttribute("medicine", medicine);
				session.setAttribute("medicinedose", medicinedose);
				session.setAttribute("date", date);
				session.setAttribute("prescriptionid", prescriptionid);
				out.println("</form>");
			}
			
		}
		catch(ClassNotFoundException d)
		{
			System.out.println(d);
		}
		catch(SQLException e)
		{
			System.out.println(e);
		}
		out.println("</body>");
		out.println("</html>");
	}

	
}

