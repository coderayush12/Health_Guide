import java.io.*;


import jakarta.servlet.ServletException;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.sql.*;
/**
 * Servlet implementation class pr2
 */
public class pr2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public pr2() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		try
		{
			
			
			if(request.getParameter("Register")!=null)
			{
				
				
				int id=Integer.parseInt(request.getParameter("pid"));
				String pname=request.getParameter("pname");
				int page=Integer.parseInt(request.getParameter("page"));
				String bg=request.getParameter("bg");
				String email=request.getParameter("eid");
				String mob=request.getParameter("mob");
				String state=request.getParameter("state");
				String city=request.getParameter("city");
				String country=request.getParameter("country");
				int pinno=Integer.parseInt(request.getParameter("pin"));
				String password=request.getParameter("password");
				String aadhaar=request.getParameter("aadhaar");
				String st="insert into patient values(?,?,?,?,?,?,?,?,?,?,?,?)";
				Class.forName("com.mysql.cj.jdbc.Driver");
				String url="jdbc:mysql://localhost:3306/pas?characterEncoding=utf8";
				Connection conn=DriverManager.getConnection(url,"root","abcde");
				PreparedStatement pstatement=conn.prepareStatement(st);
				pstatement.setInt(1,id);
				pstatement.setString(2,pname);
				pstatement.setInt(3,page);
				pstatement.setString(4,bg);
				pstatement.setString(5,email);
				pstatement.setString(6,mob);
				pstatement.setString(7,state);
				pstatement.setString(8,city);
				pstatement.setString(9,country);
				pstatement.setInt(10,pinno);
				pstatement.setString(11,password);
				pstatement.setString(12,aadhaar);
				pstatement.executeUpdate();
				out.println("<html>");
				out.println("<body>");
				out.println("<h1>RECORD INSERTED SUCCESSFULLY</h1>");
			}
			else if(request.getParameter("Login")!=null)
			{
				response.sendRedirect("pr7.html");
			}
			else if(request.getParameter("Search")!=null)
			{
				response.sendRedirect("pr5.html");
			}
			else if(request.getParameter("Searchbycity")!=null)
			{
				response.sendRedirect("pr6.html");
			}
		}
		catch(ClassNotFoundException e)
		{
			System.out.println(e);
		}
		catch(SQLException d)
		{
			System.out.println(d);
		}
		out.println("</body>");
		out.println("</html>");
	}
	}


