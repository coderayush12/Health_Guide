import java.io.*;



import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.*;
/**
 * Servlet implementation class pr7
 */
public class pr7 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public pr7() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		try
		{
			if(request.getParameter("Search")!=null)
			{
				out.println("<html>");
				out.println("<head>");
				out.println("<title>SEARCH</title>");
				out.println("</head>");
				out.println("<body>");
				int pid=0,page=0,pinno=0;
				String pname="",bloodgroup="",emailid="",mobileno="",state="",city="",country="",password="",aadhaarno="";
				String st="select * from patient where patientid=?;";
				Class.forName("com.mysql.cj.jdbc.Driver");
				String url="jdbc:mysql://localhost:3306/pas?characterEncoding=utf8";
				Connection conn=DriverManager.getConnection(url,"root","abcde");
				PreparedStatement pstatement=conn.prepareStatement(st);
				int ptid=Integer.parseInt(request.getParameter("pid"));
				pstatement.setInt(1, ptid);
				ResultSet rs=pstatement.executeQuery();
				out.println("<html>");
				out.println("<head><title>SEARCH PATIENT DETAILS</title></head>");
				out.println("<body>");
				out.println("<br><br>");
				out.println("<h1 style='color:purple;background-color:yellow;width:460px;'>DISPLAY PATIENT DETAILS</h1>");
				out.println("<br>");
				out.println("<table style='width:100%;'>");
				out.println("<tr style='color:white;background-color:black;'><th>"+"PatientId"+"</th><th>"+"PatientName"+"</th><th>"+"PatientAge"+"</th><th>"+"BloodGroup"+"</th><th>"+"EmailId"+"</th><th>"+"MobileNo"+"</th><th>"+"State"+"</th><th>"+"City"+"</th><th>"+"Country"+"</th><th>"+"Pinno"+"</th><th>"+"Password"+"</th><th>"+"AadhaarNo"+"</th></tr>");
				while(rs.next())
				{
					pid=rs.getInt("patientid");
					pname=rs.getString("patientname");
					page=rs.getInt("patientage");
					bloodgroup=rs.getString("bloodgroup");
					emailid=rs.getString("emailid");
					mobileno=rs.getString("mobileno");
					state=rs.getString("state");
					city=rs.getString("city");
					country=rs.getString("country");
					pinno=rs.getInt("pinno");
					password=rs.getString("password");
					aadhaarno=rs.getString("aadhaarno");
					out.println("<tr style='color:purple;background-color:yellow;'><td>"+pid+"</td><td>"+pname+"</td><td>"+page+"</td><td>"+bloodgroup+"</td><td>"+emailid+"</td><td>"+mobileno+"</td><td>"+state+"</td><td>"+city+"</td><td>"+country+"</td><td>"+pinno+"</td><td>"+password+"</td><td>"+aadhaarno+"</td></tr>");
					out.println("<br>");
				}
				out.println("</table>");
			}
		}
		catch(ClassNotFoundException e)
		{
			System.out.println(e);
		}
		catch(SQLException d)
		{
			System.out.println(d);
		}
		out.println("</body>");
		out.println("</html>");
	}

}
