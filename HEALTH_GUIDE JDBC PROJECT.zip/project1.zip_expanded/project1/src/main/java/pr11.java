import java.io.*;



import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.*;
/**
 * Servlet implementation class pr11
 */
public class pr11 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public pr11() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		HttpSession session=request.getSession(true);
		try
		{
			if(request.getParameter("Search")!=null) {
				out.println("<html>");
				out.println("<head>");
				out.println("<title>DISPLAY PATIENT DETAILS</title>");
				out.println("</head>");
				out.println("<body>");
				String patientid=String.valueOf(session.getAttribute("paid"));
				String dname=String.valueOf(session.getAttribute("dname"));
				String pres=String.valueOf(session.getAttribute("pres"));
				String medicine=String.valueOf(session.getAttribute("medicine"));
				String medicinedose=String.valueOf(session.getAttribute("medicinedose"));
				String date=String.valueOf(session.getAttribute("date"));
				String st="select * from prescription where prescriptionid=?;";
				Class.forName("com.mysql.cj.jdbc.Driver");
				String rid=null;
				String url="jdbc:mysql://localhost:3306/pas?characterEncoding=utf8";
				Connection conn=DriverManager.getConnection(url,"root","abcde");
				PreparedStatement pstatement=conn.prepareStatement(st);
				String prescriptionid=request.getParameter("prid");
				pstatement.setString(1, prescriptionid);
				ResultSet rs=pstatement.executeQuery();
				out.println("<br><br>");
				out.println("<h1 style='color:purple;background-color:yellow;width:300px;'>PATIENT DETAILS</h1>");
				out.println("<table style='width:100%;'>");
				out.println("<tr style='color:white;background-color:black;'><th>&emsp;"+"RecordId"+"</th><th>"+"PrescriptionId"+"</th><th>&emsp;"+"PatientId"+"</th><th>&emsp;"+"DiseaseName"+"</th><th>&emsp;"+"Prescription"+"</th><th>&emsp;"+"Medicine"+"</th><th>&emsp;"+"MedicineDose"+"</th><th>&emsp;"+"Date"+"</th></tr>");
				while(rs.next()) {
					prescriptionid=rs.getString("prescriptionid");
					patientid=rs.getString("patientid");
					rid=rs.getString("recordid");
					dname=rs.getString("diseasename");
					pres=rs.getString("prescription");
					medicine=rs.getString("medicine");
					medicinedose=rs.getString("medicinedose");
					date=rs.getString("date");
					out.println("<tr style='color:purple;background-color:yellow;'><td>&emsp;"+rid+"</td><td>"+prescriptionid+"</td><td>&emsp;"+patientid+"</td><td>&emsp;"+dname+"</td><td>&emsp;"+pres+"</td><td>&emsp;"+medicine+"</td><td>&emsp;"+medicinedose+"</td><td>&emsp;"+date+"</td></tr>");
					out.println("<br>");
				}
				out.println("</table>");
			}
		}
		catch(ClassNotFoundException e)
		{
			System.out.println(e);
		}
		catch(SQLException d)
		{
			System.out.println(d);
		}
		out.println("</body>");
		out.println("</html>");
	}

}
