import java.io.*;


import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.*;
/**
 * Servlet implementation class pr5
 */
public class pr5 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public pr5() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		try
		{
			if(request.getParameter("Delete")!=null)
			{
				out.println("<html>");
				out.println("<body>");
				out.println("<form method='post' action='pr6'>");
				int pid=0,page=0,pinno=0;
				String pname="",bloodgroup="",emailid="",mobileno="",state="",city="",country="",password="",aadhaarno="";
				String st="select * from patient where patientid=?;";
				Class.forName("com.mysql.cj.jdbc.Driver");
				String url="jdbc:mysql://localhost:3306/pas?characterEncoding=utf8";
				Connection conn=DriverManager.getConnection(url,"root","abcde");
				PreparedStatement pstatement=conn.prepareStatement(st);
				int prid=Integer.parseInt(request.getParameter("pid"));
				pstatement.setInt(1, prid);
				ResultSet rs=pstatement.executeQuery();
				while(rs.next())
				{
					pid=rs.getInt("patientid");
					pname=rs.getString("patientname");
					page=rs.getInt("patientage");
					bloodgroup=rs.getString("bloodgroup");
					emailid=rs.getString("emailid");
					mobileno=rs.getString("mobileno");
					state=rs.getString("state");
					city=rs.getString("city");
					country=rs.getString("country");
					pinno=rs.getInt("pinno");
					password=rs.getString("password");
					aadhaarno=rs.getString("aadhaarno");
				}
				out.println("<br><br>");
				out.println("<label>patientid</label>&emsp;");
				out.println("<input type='text' name='prid' value="+pid+">");
				out.println("<br><br>");
				out.println("<label>patientname</label>&emsp;");
				out.println("<label>"+pname+"<label>");
				out.println("<br><br>");
				out.println("<label>patientage</label>&emsp;");
				out.println("<label>"+page+"</label>");
				out.println("<br><br>");
				out.println("<label>bloodgroup</label>");
				out.println("<label>"+bloodgroup+"</label>");
				out.println("<br><br>");
				out.println("<label>emailid</label>");
				out.println("<label>"+emailid+"</label>");
				out.println("<br><br>");
				out.println("<label>mobileno</label>");
				out.println("<label>"+mobileno+"</label>");
				out.println("<br><br>");
				out.println("<label>state</label>");
				out.println("<label>"+state+"</label>");
				out.println("<br><br>");
				out.println("<label>city</label>");
				out.println("<label>"+city+"</label>");
				out.println("<br><br>");
				out.println("<label>country</label>");
				out.println("<label>"+country+"</label>");
				out.println("<br><br>");
				out.println("<label>pinno</label>");
				out.println("<label>"+pinno+"</label>");
				out.println("<br><br>");
				out.println("<label>password</label>");
				out.println("<label>"+password+"</label>");
				out.println("<br><br>");
				out.println("<label>aadhaarno</label>");
				out.println("<label>"+aadhaarno+"</label>");
				out.println("<br>");
				out.println("<input type='submit' name='Delete' value='Delete'>");
			}
		}
		catch(ClassNotFoundException e)
		{
			System.out.println(e);
		}
		catch(SQLException d)
		{
			System.out.println(d);
		}
		out.println("</form>");
		out.println("</body>");
		out.println("</html>");
	}

}
