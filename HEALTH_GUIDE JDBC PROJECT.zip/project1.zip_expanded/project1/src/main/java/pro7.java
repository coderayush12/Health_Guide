import java.io.*;



import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.*;
/**
 * Servlet implementation class pro7
 */
public class pro7 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public pro7() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		HttpSession session=request.getSession(true);
		if(request.getParameter("Search")!=null)
		{
		try
		{
				out.println("<html>");
				out.println("<head>");
				out.println("<title>SEARCH PATIENT</title>");
				out.println("</head>");
				out.println("<body>");
				out.println("<form method='post' action='pro8'>");
				int pid=0,page=0,pinno=0;
				String pname="",bloodgroup="",emailid="",mobileno="",state="",city="",country="",password="",aadhaarno="";
				String st="select * from patient where patientid=?;";
				Class.forName("com.mysql.cj.jdbc.Driver");
				String url="jdbc:mysql://localhost:3306/pas?characterEncoding=utf8";
				Connection conn=DriverManager.getConnection(url,"root","abcde");
				PreparedStatement pstatement=conn.prepareStatement(st);
				int ptid=Integer.parseInt(request.getParameter("pid"));
				pstatement.setInt(1, ptid);
				ResultSet rs=pstatement.executeQuery();
				while(rs.next())
				{
					pid=rs.getInt("patientid");
					pname=rs.getString("patientname");
					page=rs.getInt("patientage");
					bloodgroup=rs.getString("bloodgroup");
					emailid=rs.getString("emailid");
					mobileno=rs.getString("mobileno");
					state=rs.getString("state");
					city=rs.getString("city");
					country=rs.getString("country");
					pinno=rs.getInt("pinno");
					password=rs.getString("password");
					aadhaarno=rs.getString("aadhaarno");
				}
				out.println("<br><br>");
				out.println("<h1 style='color:purple;background-color:yellow;width:460px;'>DISPLAY PATIENT DETAILS</h1>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>patientid</label>&emsp;&emsp;");
				out.println("<input type='text' name='paid' value="+pid+">");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>patientname</label>&emsp;");
				out.println("<label>"+pname+"</label>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>patientage</label>&emsp;&ensp;&nbsp;");
				out.println("<label>"+page+"</label>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>bloodgroup</label>&emsp;&ensp;");
				out.println("<label>"+bloodgroup+"</label>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>emailid</label>&emsp;&emsp;&emsp;");
				out.println("<label>"+emailid+"</label>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>mobileno</label>&emsp;&emsp;&nbsp;");
				out.println("<label>"+mobileno+"</label>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>state</label>&emsp;&emsp;&emsp;&emsp;&nbsp;");
				out.println("<label>"+state+"</label>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>city</label>&emsp;&emsp;&emsp;&emsp;&ensp;");
				out.println("<label>"+city+"</label>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>country</label>&emsp;&emsp;&emsp;");
				out.println("<label>"+country+"</label>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>pinno</label>&emsp;&emsp;&emsp;&ensp;&nbsp;");
				out.println("<label>"+pinno+"</label>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>password</label>&emsp;&emsp;&nbsp;");
				out.println("<label>"+password+"</label>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>aadhaarno</label>&emsp;&emsp;");
				out.println("<label>"+aadhaarno+"</label>");
				out.println("<br><br>");
				out.println("<input type='submit' name='InsertPrescription' value='InsertPrescription' style='color:white;background-color:purple;'>&emsp;");
				out.println("<input type='submit' name='ViewOpenPrescription' value='ViewOpenPrescription' style='color:white;background-color:purple;'>&emsp;");
				out.println("<input type='submit' name='ViewClosedPrescription' value='ViewClosedPrescription' style='color:white;background-color:purple;'>&emsp;");
				out.println("<input type='submit' name='SearchOpenPrescription' value='SearchOpenPrescription' style='color:white;background-color:purple;'>&emsp;");
				out.println("<input type='submit' name='SearchClosedPrescription' value='SearchClosedPrescription' style='color:white;background-color:purple;'>&emsp;");
				out.println("<input type='submit' name='ClosePrescription' value='ClosePrescription' style='color:white;background-color:purple;'>");
				session.setAttribute("pid",pid);
			}
		
		catch(ClassNotFoundException e)
		{
			System.out.println(e);
		}
		catch(SQLException d)
		{
			System.out.println(d);
		}
		out.println("</form>");
		out.println("</body>");
		out.println("</html>");
		}
	}

}
