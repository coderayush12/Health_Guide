import java.io.*;



import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.*;
/**
 * Servlet implementation class pr12
 */
public class pr12 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public pr12() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		HttpSession session=request.getSession(true);
		try 
		{
			if(request.getParameter("SearchByDate")!=null) {
				out.println("<html>");
				out.println("<head>");
				out.println("<title>SEARCH PRESCRIPTIONS BY DATE</title>");
				out.println("</head>");
				out.println("<body>");
				String st="select * from prescription where date=?;";
				Class.forName("com.mysql.cj.jdbc.Driver");
				String url="jdbc:mysql://localhost:3306/pas?characterEncoding=utf8";
				Connection conn=DriverManager.getConnection(url,"root","abcde");
				PreparedStatement pstatement=conn.prepareStatement(st);
				String date=request.getParameter("date");
				String recordid=String.valueOf(session.getAttribute("recordid"));
				String prescriptionid=String.valueOf(session.getAttribute("prid"));
				String patientid=String.valueOf(session.getAttribute("pid"));
				String dname=String.valueOf(session.getAttribute("dname"));
				String prescription=String.valueOf(session.getAttribute("pres"));
				String medicine=String.valueOf(session.getAttribute("medicine"));
				String medicinedose=String.valueOf(session.getAttribute("medicinedose"));
				pstatement.setString(1, date);
				ResultSet rs=pstatement.executeQuery();
				out.println("<br><br>");
				out.println("<h1 style='color:purple;background-color:yellow;width:450px;'>DISPLAY PRESCRIPTIONS</h1>");
				out.println("<table style='width:100%;'>");
				out.println("<tr style='color:white;background-color:black;'><th>"+"RecordId"+"</th><th>&emsp;"+"PatientId"+"</th><th>&emsp;"+"DiseaseName"+"</th><th>&emsp;"+"Prescription"+"</th><th>&emsp;"+"Medicine"+"</th><th>&emsp;"+"MedicineDose"+"</th><th>&emsp;"+"Date"+"</th><th>"+"PrescriptionId"+"</th></tr>");
				while(rs.next()) {
					recordid=rs.getString("recordid");
					patientid=rs.getString("patientid");
					dname=rs.getString("diseasename");
					prescription=rs.getString("prescription");
					medicine=rs.getString("medicine");
					medicinedose=rs.getString("medicinedose");
					date=rs.getString("date");
					prescriptionid=rs.getString("prescriptionid");
					
					out.println("<tr style='color:purple;background-color:yellow;'><td>"+recordid+"</td><td>&emsp;"+patientid+"</td><td>&emsp;"+dname+"</td><td>&emsp;"+prescription+"</td><td>&emsp;"+medicine+"</td><td>&emsp;"+medicinedose+"</td><td>&emsp;"+date+"</td><td>"+prescriptionid+"</td></tr>");
					out.println("<br><br>");
					out.println("</table>");
				}
			}
		}
		catch(SQLException e) {
			System.out.println(e);
		}
		catch(ClassNotFoundException d) {
			System.out.println(d);
		}
	}

}
