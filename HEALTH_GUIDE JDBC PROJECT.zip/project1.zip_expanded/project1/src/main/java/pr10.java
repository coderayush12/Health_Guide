import java.io.*;



import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.*;
/**
 * Servlet implementation class pr10
 */
public class pr10 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public pr10() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		HttpSession session=request.getSession(true);
		
		out.println("<html>");
		out.println("<body>");
		try
		{
			
			if(request.getParameter("Update")!=null)
			{
				out.println("<head><title>UPDATE PATIENT DETAILS</title></head>");
				out.println("<form action='pr4' method='post'>");
				int pid=0,page=0,pinno=0;
				String pname="",bloodgroup="",emailid="",mobileno="",state="",city="",country="",password="",aadhaarno="";
				String st="select * from patient where emailid=?;";
				Class.forName("com.mysql.cj.jdbc.Driver");
				String url="jdbc:mysql://localhost:3306/pas?characterEncoding=utf8";
				Connection conn=DriverManager.getConnection(url,"root","abcde");
				PreparedStatement pstatement=conn.prepareStatement(st);
				String email=String.valueOf(session.getAttribute("email1"));
				pstatement.setString(1, email);
				ResultSet rs=pstatement.executeQuery();
				while(rs.next())
				{
					pid=rs.getInt("patientid");
					pname=rs.getString("patientname");
					page=rs.getInt("patientage");
					bloodgroup=rs.getString("bloodgroup");
					emailid=rs.getString("emailid");
					mobileno=rs.getString("mobileno");
					state=rs.getString("state");
					city=rs.getString("city");
					country=rs.getString("country");
					pinno=rs.getInt("pinno");
					password=rs.getString("password");
					aadhaarno=rs.getString("aadhaarno");
				}
				out.println("<br><br>");
				out.println("<h1 style='color:purple;background-color:yellow;width:460px;'>UPDATE PATIENT'S DETAILS</h1>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>Patient Id</label>&emsp;&ensp;&ensp;&nbsp;");
				out.println("<input type='text' name='prid' value="+pid+" style='color:black;background-color:yellow;'>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>Patient Name</label>&nbsp;&ensp;");
				out.println("<input type='text' name='pnam' value="+pname+" style='color:black;background-color:yellow;'>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>Patient Age</label>&emsp;&ensp;");
				out.println("<input type='text' name='pag' value="+page+" style='color:black;background-color:yellow;'>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>Blood Group</label>&ensp;&ensp;");
				out.println("<input type='text' name='bgr' value="+bloodgroup+" style='color:black;background-color:yellow;'>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>Email Id</label>&emsp;&emsp;&ensp;&nbsp;");
				out.println("<input type='text' name='email' value="+emailid+" style='color:black;background-color:yellow;'>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>Mobile No</label>&emsp;&nbsp;&ensp;&nbsp;");
				out.println("<input type='text' name='mob' value="+mobileno+" style='color:black;background-color:yellow;'>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>State</label>&emsp;&emsp;&emsp;&nbsp;&ensp;&ensp;");
				out.println("<input type='text' name='stat' value="+state+" style='color:black;background-color:yellow;'>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>City</label>&emsp;&emsp;&emsp;&ensp;&emsp;");
				out.println("<input type='text' name='cit' value="+city+" style='color:black;background-color:yellow;'>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>Country</label>&emsp;&emsp;&ensp;&nbsp;");
				out.println("<input type='text' name='countr' value="+country+" style='color:black;background-color:yellow;'>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>Pinno</label>&emsp;&emsp;&ensp;&nbsp;&ensp;&ensp;");
				out.println("<input type='text' name='pin' value="+pinno+" style='color:black;background-color:yellow;'>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>Password</label>&emsp;&nbsp;&ensp;&ensp;");
				out.println("<input type='text' name='passwo' value="+password+" style='color:black;background-color:yellow;'>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>Aadhaarno</label>&emsp;&ensp;&nbsp;");
				out.println("<input type='text' name='aadhaa' value="+aadhaarno+" style='color:black;background-color:yellow;'>");
				out.println("<br><br>");
				out.println("<input type='submit' name='Update' value='Update' style='color:white;background-color:purple;'>");
				out.println("</form>");
			}
			else if(request.getParameter("Delete")!=null)
			{
				out.println("<head><title>DELETE PATIENT DETAILS</title></head>");
				out.println("<form method='post' action='pr6'>");
				int pid=0,page=0,pinno=0;
				String pname="",bloodgroup="",emailid="",mobileno="",state="",city="",country="",password="",aadhaarno="";
				String st2="select * from patient where emailid=?;";
				Class.forName("com.mysql.jdbc.Driver");
				String url="jdbc:mysql://localhost:3306/pas?characterEncoding=utf8";
				Connection conn=DriverManager.getConnection(url,"root","abcde");
				PreparedStatement pstatement=conn.prepareStatement(st2);
				String email=String.valueOf(session.getAttribute("email1"));
				pstatement.setString(1, email);
				ResultSet rs=pstatement.executeQuery();
				while(rs.next())
				{
					pid=rs.getInt("patientid");
					pname=rs.getString("patientname");
					page=rs.getInt("patientage");
					bloodgroup=rs.getString("bloodgroup");
					emailid=rs.getString("emailid");
					mobileno=rs.getString("mobileno");
					state=rs.getString("state");
					city=rs.getString("city");
					country=rs.getString("country");
					pinno=rs.getInt("pinno");
					password=rs.getString("password");
					aadhaarno=rs.getString("aadhaarno");
				}
				out.println("<br><br>");
				out.println("<h1 style='color:purple;background-color:yellow;width:460px;'>DELETE PATIENT'S DETAILS</h1>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>Patient Id</label>&emsp;&emsp;&ensp;");
				out.println("<label>"+pid+"</label>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>Patient Name</label>&ensp;&nbsp;");
				out.println("<label>"+pname+"</label>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>Patient Age</label>&emsp;&nbsp;&ensp;");
				out.println("<label>"+page+"</label>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>Blood Group</label>&emsp;&nbsp;");
				out.println("<label>"+bloodgroup+"</label>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>Email Id</label>&emsp;&emsp;&nbsp;");
				out.println("<input type='text' name='email' value="+emailid+" style='color:black;background-color:yellow;'>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>Mobile No</label>&emsp;&ensp;");
				out.println("<label>"+mobileno+"</label>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>State</label>&emsp;&emsp;&emsp;&ensp;&ensp;");
				out.println("<label>"+state+"</label>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>City</label>&emsp;&emsp;&emsp;&emsp;&nbsp;");
				out.println("<label>"+city+"</label>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>Country</label>&emsp;&emsp;&ensp;&nbsp;");
				out.println("<label>"+country+"</label>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>Pinno</label>&emsp;&emsp;&emsp;&ensp;");
				out.println("<label>"+pinno+"</label>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>Password</label>&emsp;&ensp;&ensp;");
				out.println("<label>"+password+"</label>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>Aadhaarno</label>&emsp;&ensp;");
				out.println("<label>"+aadhaarno+"</label>");
				out.println("<br><br>");
				out.println("<input type='submit' name='Delete' value='Delete' style='color:white;background-color:purple;'>");
				out.println("</form>");
				
			}
			else if(request.getParameter("ViewPersonalDetails")!=null)
			{
				
				String st1="select * from patient where emailid=?;";
				Class.forName("com.mysql.jdbc.Driver");
				String url="jdbc:mysql://localhost:3306/pas?characterEncoding=utf8";
				Connection conn=DriverManager.getConnection(url,"root","abcde");
				PreparedStatement pstatement2=conn.prepareStatement(st1);
				String email=String.valueOf(session.getAttribute("email1"));
				pstatement2.setString(1, email);
				ResultSet rs2=pstatement2.executeQuery();
				int pid,page;
				String pname,mobileno;
				out.println("<html>");
				out.println("<head><title>VIEW PATIENT DETAILS</title></head>");
				out.println("<body>");
				out.println("<br><br>");
				out.println("<h1 style='color:purple;background-color:yellow;width:460px;'>DISPLAY PATIENT DETAILS</h1>");
				out.println("<br>");
				out.println("<table style='width:100%;'>");
				out.println("<tr style='color:white;background-color:black;'><th>"+"PatientId"+"</th><th>"+"PatientName"+"</th><th>"+"PatientAge"+"</th><th>"+"EmailId"+"</th><th>"+"MobileNo"+"</th></tr>");
				while(rs2.next())
				{
					pid=rs2.getInt("patientid");
					pname=rs2.getString("patientname");
					page=rs2.getInt("patientage");
					email=rs2.getString("emailid");
					mobileno=rs2.getString("mobileno");
					out.println("<tr style='color:purple;background-color:yellow;'><td>"+pid+"</td><td>"+pname+"</td><td>"+page+"</td><td>"+email+"</td><td>"+mobileno+"</td></tr>");
					out.println("<br>");
				}
				out.println("</table>");
			}
			else if(request.getParameter("ViewOpenPrescription")!=null) 
			{
				
				out.println("<head><title>VIEW OPEN PRESCRIPTION</title></head>");
				String st3="select * from prescription";
				Class.forName("com.mysql.jdbc.Driver");
				String url="jdbc:mysql://localhost:3306/pas?characterEncoding=utf8";
				Connection conn=DriverManager.getConnection(url,"root","abcde");
				PreparedStatement pstatement=conn.prepareStatement(st3);
				ResultSet rs=pstatement.executeQuery();
				int rid,pid;
				String dname,pres,medicine,medicinedose,date,prid;
				out.println("<br><br>");
				out.println("<h1 style='color:purple;background-color:yellow;width:530px;'>DISPLAY OPEN PRESCRIPTIONS</h1>");
				out.println("<br>");
				out.println("<table style='width:100%;'>");
				out.println("<tr style='color:white;background-color:black;'><th>"+"RecordId"+"</th><th>"+"PrescriptionId"+"</th><th>"+"PatientId"+"</th><th>"+"Diseasename"+"</th><th>"+"Prescription"+"</th><th>"+"Medicine"+"</th><th>"+"MedicineDose"+"</th><th>"+"Date"+"</th></tr>");
				while(rs.next()) {
					rid=rs.getInt("recordid");
					prid=rs.getString("prescriptionid");
					pid=rs.getInt("patientid");
					dname=rs.getString("diseasename");
					pres=rs.getString("prescription");
					medicine=rs.getString("medicine");
					medicinedose=rs.getString("medicinedose");
					date=rs.getString("date");
					out.println("<tr style='color:purple;background-color:yellow;'><td>"+rid+"</td><td>"+prid+"</td><td>"+pid+"</td><td>"+dname+"</td><td>"+pres+"</td><td>"+medicine+"</td><td>"+medicinedose+"</td><td>"+date+"</td></tr>");
					out.println("<br>");
				}
				out.println("</table>");
			}
			else if(request.getParameter("ViewClosedPrescription")!=null) {
				String st="select * from close;";
				Class.forName("com.mysql.jdbc.Driver");
				String url="jdbc:mysql://localhost:3306/pas?characterEncoding=utf8";
				Connection conn=DriverManager.getConnection(url,"root","abcde");
				PreparedStatement pstatement=conn.prepareStatement(st);
				ResultSet rs=pstatement.executeQuery();
				String pid,dname,prescription,medicine,medicinedose,date;
				String prescriptionid;
				out.println("<head><title>VIEW CLOSED PRESCRIPTIONS</title></head>");
				out.println("<br><br>");
				out.println("<h1 style='color:purple;background-color:yellow;width:550px;'>DISPLAY CLOSED PRESCRIPTIONS</h1>");
				out.println("<br>");
				out.println("<table style='width:100%;'>");
				out.println("<tr style='color:white;background-color:black;'><th>"+"PrescriptionId"+"</th><th>"+"PatientId"+"</th><th>"+"DiseaseName"+"</th><th>"+"Prescription"+"</th><th>"+"Medicine"+"</th><th>"+"MedicineDose"+"</th><th>"+"Date"+"</th></tr>");
				while(rs.next()) {
					prescriptionid=rs.getString("prescriptionid");
					pid=rs.getString("patientid");
					dname=rs.getString("diseasename");
					prescription=rs.getString("prescription");
					medicine=rs.getString("medicine");
					medicinedose=rs.getString("medicinedose");
					date=rs.getString("date");
					out.println("<tr style='color:purple;background-color:yellow;'><td>"+prescriptionid+"</td><td>"+pid+"</td><td>"+dname+"</td><td>"+prescription+"</td><td>"+medicine+"</td><td>"+medicinedose+"</td><td>"+date+"</td></tr>");
					out.println("<br>");
				}
				out.println("</table>");
			}
			else if(request.getParameter("SearchPrescription")!=null) {
				out.println("<form action='pr11' method='post'>");
				out.println("<br>");
				out.println("<h1 style='color:purple;background-color:yellow;width:570px;'>SEARCH PATIENT'S PRESCRIPTION</h1>");
				out.println("<br>");
				out.println("<label style='color:white;background-color:black;'>Prescription id</label>");
				out.println("<label style='color:red;'>*</label>&emsp;");
				out.println("<input type='text' name='prid' required>&emsp;");
				out.println("<input type='submit' name='Search' value='Search' style='color:white;background-color:purple;'>");
				out.println("</form>");
			}
			else if(request.getParameter("SearchPrescriptionByDate")!=null) {
				out.println("<form action='pr12' method='post'>");
				out.println("<br>");
				out.println("<h1 style='color:purple;background-color:yellow;width:230px;'>ENTER DATE</h1>");
				out.println("<br>");
				out.println("<label style='color:white;background-color:black;'>Date</label>");
				out.println("<label style='color:red;'>*</label>&emsp;");
				out.println("<input type='text' name='date'>&emsp;");
				out.println("<input type='submit' name='SearchByDate' value='SearchByDate' style='color:white;background-color:purple;'>");
				out.println("</form>");
			}
		}
		catch(ClassNotFoundException e)
		{
			System.out.println(e);
		}
		catch(SQLException d)
		{
			System.out.println(d);
		}
		
		
		out.println("</body>");
		out.println("</html>");
	}

}
