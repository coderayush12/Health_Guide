import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class pro10
 */
public class pro10 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public pro10() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		response.setContentType("text/html");
		try
		{
			String st="select * from doctor;";
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/pas?characterEncoding=utf8";
			Connection conn=DriverManager.getConnection(url,"root","abcde");
			PreparedStatement pstatement=conn.prepareStatement(st);
			
			if(request.getParameter("DoctorsRegisteration")!=null) {
				response.sendRedirect("pro1.html");
			}
			else if(request.getParameter("DoctorsLogin")!=null) {
				response.sendRedirect("pro3.html");
			}
			else if(request.getParameter("PatientsRegistration")!=null) {
				response.sendRedirect("p1.html");
			}
			else if(request.getParameter("PatientsLogin")!=null) {
				response.sendRedirect("pr7.html");
			}
			else if(request.getParameter("FirmsRegistration")!=null) {
				response.sendRedirect("o1.html");
			}
			else if(request.getParameter("FirmsLogin")!=null) {
				response.sendRedirect("o2.html");
			}
			else if(request.getParameter("SearchPatient")!=null) {
				response.sendRedirect("pr5.html");
			}
			else if(request.getParameter("SearchPatientbycity")!=null) {
				response.sendRedirect("pr6.html");
			}
			pstatement.execute();
		}
		catch(ClassNotFoundException d)
		{
			System.out.println(d);
		}
		catch(SQLException e)
		{
			System.out.println(e);
		}
	}

}
