import java.io.*;



import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.*;
/**
 * Servlet implementation class pr9
 */
public class pr9 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public pr9() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		int count=0;
		String password="";
		out.println("<html>");
		out.println("<head>");
		out.println("<title>DETAILS</title>");
		out.println("</head>");
		out.println("<body>");
		out.println("<form method='post' action='pr10'>");
		HttpSession session=request.getSession(true); 
		try
		{
			String st="select * from patient where emailid=?;";
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/pas?characterEncoding=utf8";
			Connection conn=DriverManager.getConnection(url,"root","abcde");
			PreparedStatement pstatement=conn.prepareStatement(st);
			String email1=request.getParameter("email");
			String pwd=request.getParameter("password");
			pstatement.setString(1, email1);
			ResultSet rs=pstatement.executeQuery();
			
			
			while(rs.next())
			{
				password=rs.getString("password");
				count++;
			}
			if(count==0)
			{
				out.println("<h1>LOGIN ID AND PASSWORD ARE INCORRECT</h1>");
			}
			
			else if(!pwd.equals(password))
			{
				out.println("<h1>PASSWORD IS INCORRECT</h1>");
			}
			else if(pwd.equals(password))
			{
				out.println("<br><br>");
				out.println("<label><center style='color:purple;background-color:yellow;'><b>WELCOME</center></label>");
				out.println("<label><center style='color:purple;background-color:yellow;'><b>"+email1+"</center></label>");
				out.println("<br><br>");
				out.println("<input type='submit' name='Update' value='Update' style='color:white;background-color:purple;width:5%;'>");
				out.println("&emsp;&emsp;&emsp;&emsp;");
				out.println("<input type='submit' name='Delete' value='Delete' style='color:white;background-color:purple;width:5%;'>");
				out.println("&emsp;&emsp;&emsp;&emsp;");
				out.println("<input type='submit' name='ViewPersonalDetails' value='ViewPersonalDetails' style='color:white;background-color:purple;width:10%;'>");
				out.println("&emsp;&emsp;&emsp;&emsp;");
				out.println("<input type='submit' name='ViewOpenPrescription' value='ViewOpenPrescription' style='color:white;background-color:purple;width:12%;'>");
				out.println("&emsp;&emsp;&emsp;&emsp;");
				out.println("<input type='submit' name='ViewClosedPrescription' value='ViewClosedPrescription' style='color:white;background-color:purple;width:12%;'>");
				out.println("&emsp;&emsp;&emsp;&emsp;");
				out.println("<input type='submit' name='SearchPrescription' value='SearchPrescription' style='color:white;background-color:purple;width:10%;'>");
				out.println("&emsp;&emsp;&emsp;&emsp;");
				out.println("<input type='submit' name='SearchPrescriptionByDate' value='SearchPrescriptionByDate' style='color:white;background-color:purple;width:14%;'>");
				session.setAttribute("email1",email1);
			}
		}
		catch(ClassNotFoundException e)
		{
			System.out.println(e);
		}
		catch(SQLException d)
		{
			System.out.println(d);
		}
		out.println("</form>");
		out.println("</body>");
		out.println("</html>");
	}

}
