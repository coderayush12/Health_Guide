import java.io.*;


import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.*;
/**
 * Servlet implementation class o5
 */
public class o5 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public o5() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		out.println("<html>");
		out.println("<body>");
		out.println("<form action='o6' method='post'>");
		try
		{
			if(request.getParameter("Submit")!=null)
			{
				out.println("<head><title>UPDATE FIRM DETAILS</title></head>");
				String st="select * from otherusers where id=?;";
				Class.forName("com.mysql.cj.jdbc.Driver");
				String url="jdbc:mysql://localhost:3306/pas?characterEncoding=utf8";
				Connection conn=DriverManager.getConnection(url,"root","abcde");
				PreparedStatement pstatement=conn.prepareStatement(st);
				int fid=Integer.parseInt(request.getParameter("oid"));
				pstatement.setInt(1, fid);
				ResultSet rs=pstatement.executeQuery();
				int id=0,pinno=0;
				String fname="",email="",mob="",address="",city="",state="",country="",ftype="",password="",fno="";
				while(rs.next())
				{
					id=rs.getInt("id");
					fname=rs.getString("firmname");
					email=rs.getString("email");
					mob=rs.getString("mobileno");
					address=rs.getString("address");
					city=rs.getString("city");
					state=rs.getString("state");
					country=rs.getString("country");
					ftype=rs.getString("firmtype");
					pinno=rs.getInt("pinno");
					password=rs.getString("password");
					fno=rs.getString("firmno");
				}
				out.println("<br><br>");
				out.println("<h1 style='color:purple;background-color:yellow;width:400px;'>UPDATE FIRM DETAILS</h1>");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>Id</label>&emsp;&emsp;&emsp;&emsp;&nbsp;");
				out.println("<input type='text' name='fid' value="+id+">");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>Firm Name</label>&ensp;");
				out.println("<input type='text' name='fname' value="+fname+">");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>Emailid</label>&emsp;&emsp;");
				out.println("<input type='text' name='email' value="+email+">");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>Mobileno</label>&emsp;&nbsp;");
				out.println("<input type='text' name='mob' value="+mob+">");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>Address</label>&emsp;&emsp;");
				out.println("<input type='text' name='address' value="+address+">");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>City</label>&emsp;&emsp;&emsp;&ensp;");
				out.println("<input type='text' name='city' value="+city+">");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>State</label>&emsp;&emsp;&emsp;&nbsp;");
				out.println("<input type='text' name='state' value="+state+">");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>country</label>&emsp;&emsp;&nbsp;");
				out.println("<input type='text' name='country' value="+country+">");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>Firm Type</label>&emsp;");
				out.println("<input type='text' name='ftype' value="+ftype+">");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>pinno</label>&emsp;&emsp;&emsp;");
				out.println("<input type='text' name='pinno' value="+pinno+">");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>Password</label>&emsp;&ensp;");
				out.println("<input type='text' name='password' value="+password+">");
				out.println("<br><br>");
				out.println("<label style='color:white;background-color:black;'>Firmno</label>&emsp;&emsp;&nbsp;");
				out.println("<input type='text' name='fno' value="+fno+">");
				out.println("<br><br>");
				out.println("<input type='submit' name='Update' value='Update' style='color:white;background-color:purple;'>");
			}
		}
		catch(SQLException e)
		{
			System.out.println(e);
		}
		catch(ClassNotFoundException d)
		{
			System.out.println(d);
		}
		out.println("</form>");
		out.println("</body>");
		out.println("</html>");
	}

}
