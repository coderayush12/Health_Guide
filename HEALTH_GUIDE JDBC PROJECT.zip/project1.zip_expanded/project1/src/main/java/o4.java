import java.io.*;



import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.*;
/**
 * Servlet implementation class o4
 */
public class o4 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public o4() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		HttpSession session=request.getSession(true);
		out.println("<html>");
		out.println("<body>");
		out.println("<form method='post' action='o7'>");
		try
		{
			out.println("<title>DISPLAY PRESCRIPTIONS</title>");
			String st="select * from prescription where patientid=?;";
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/pas?characterEncoding=utf8";
			Connection conn=DriverManager.getConnection(url,"root","abcde");
			PreparedStatement pstatement=conn.prepareStatement(st);
			String ptid=request.getParameter("pid");
			pstatement.setString(1, ptid);
			String dname=String.valueOf(session.getAttribute("dname"));
			String prescription=String.valueOf(session.getAttribute("presciption"));
			String medicine=String.valueOf(session.getAttribute("medicine"));
			String medicinedose=String.valueOf(session.getAttribute("medicinedose"));
			String date=String.valueOf(session.getAttribute("date"));
			String rid=String.valueOf(session.getAttribute("rid"));
			String prid=String.valueOf(session.getAttribute("prid"));
			ResultSet rs=pstatement.executeQuery();
			out.println("<br><br>");
			out.println("<h1 style='color:purple;background-color:yellow;width:430px;'>DISPLAY PRESCRIPTIONS</h1>");
			out.println("<br>");
			out.println("<table style='width:100%;'>");
			out.println("<tr style='color:white;background-color:black;'><th>&emsp;"+"RecordId"+"</th><th>&emsp;"+"PrescriptionId"+"</td><th>&emsp;"+"PatientId"+"</th><th>&emsp;"+"DiseaseName"+"</th><th>&emsp;"+"Prescription"+"</th><th>&emsp;"+"Medicine"+"</th><th>&emsp;"+"MedicineDose"+"</th><th>&emsp;"+"Date"+"</th></tr>");
			while(rs.next())
			{
				prid=rs.getString("prescriptionid");
				rid=rs.getString("recordid");
				ptid=rs.getString("patientid");
				dname=rs.getString("diseasename");
				prescription=rs.getString("prescription");
				medicine=rs.getString("medicine");
				medicinedose=rs.getString("medicinedose");
				date=rs.getString("date");
				out.println("<tr style='color:purple;background-color:yellow;'><td>&emsp;"+rid+"</td><td>&emsp;"+prid+"</td><td>&emsp;"+ptid+"</td><td>&emsp;"+dname+"</td><td>&emsp;"+prescription+"</td><td>&emsp;"+medicine+"</td><td>&emsp;"+medicinedose+"</td><td>&emsp;"+date+"</td></tr>");
				out.println("<br>");
			}
			out.println("</table>");
			out.println("<br><br><br>");
			out.println("<label style='color:white;background-color:black;'>Enter PrescriptionId</label>&emsp;");
			out.println("<input type='text' name='prid'>&emsp;");
			out.println("<input type='submit' name='Submit' value='Submit' style='color:white;background-color:purple;'>");
			session.setAttribute("ptid",ptid);
			
		}
		catch(SQLException e)
		{
			System.out.println(e);
		}
		catch(ClassNotFoundException d)
		{
			System.out.println(d);
		}
		out.println("</form>");
		out.println("</body>");
		out.println("</html>");
	}

}
